import React, { useState, useEffect } from 'react';
import axios from 'axios';



const App = () => {
   const [input, setInput] = useState("");
    const [messages, setMessages] = useState([]);
    useEffect(() => {
        const eventSource = new EventSource('http://localhost:3000/subscribe');
        eventSource.onmessage = (e) => {
            console.log(e.data);
            const data = JSON.parse(e.data);
            setMessages(messages => messages.concat(data));
        }
    }, []);

    const handleChange = (e) => {
        const {target: {value}} = e;
        setInput(value);
        console.log("change", e.target.value);
    };

    const handleSubmit = (e) => {
        console.log("submit", input);
        e.preventDefault();
        axios.post('http://localhost:3000/sub/msg', {content: input}).then(() => setInput(''))
    };

    return (
        <div className="App">
            <form id="form" onSubmit={handleSubmit}>
                <input id="content" type="text" name="content" onChange={handleChange} value={input}/>
                <button type="submit">Send</button>
            </form>
            <div>
            {
                messages.map((msg) => <h1 key={msg.content}> {msg.content} </h1>)
            }
            </div>
        </div>
    );
};

export default App;
