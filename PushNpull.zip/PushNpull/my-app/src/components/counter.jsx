import React, { Component } from 'react';

class Counter extends Component {
    // state = {}
    render() {
        return (
            <>
                <h1>Hello Component !</h1>
                <button>Increment</button>
            </>
        )

    }
}

export default Counter;