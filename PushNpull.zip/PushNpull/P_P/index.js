const cors = require('cors');
const express = require('express');

const app = express();
app.use(cors);
app.use(express.json());

const messages = [{ "content": "text" }];
const subscribers = {};


app.get('/messages', (req, res) => {
    console.log("Home");
    res.json(messages);
});

app.post('/message', (req, res) => {
    const { body } = req;
    messages.push(body);
    console.log("New Message Arrived...");
    console.log(body.content);
    res.sendStatus(204).end();
});



app.post('/subscribe', (req, res) => {
    console.log('new user with id ', req.body.id);
    subscribers[req.body.id] = res;
});

app.post('/sub/msg', (req, res) => {
    const { body } = req;
    Object.keys(subscribers).forEach(sub => {
        subscribers[sub].json(body);
        delete subscribers[sub];
    });
    res.status(204).end();
});


app.listen(3000, () => {
    console.log("Server Up on port 3000 ...");

});